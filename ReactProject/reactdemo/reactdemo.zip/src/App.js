import logo from './logo.svg';
import Login from './login';
import Register from './register';
import './App.css';

function App() {
  return (
    <Login /> 
    // <Register />
  );
}

export default App;
